var searchData=
[
  ['size_5ftype_811',['size_type',['../class_ti_xml_string.html#abeb2c1893a04c17904f7c06546d0b971',1,'TiXmlString']]]
];
