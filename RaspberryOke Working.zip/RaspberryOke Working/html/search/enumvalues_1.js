var searchData=
[
  ['num_5fentity_815',['NUM_ENTITY',['../class_ti_xml_base.html#ab251e9d7b9102b9aedb2fdaed2ecfe55ab848893c6d03fcd8f42941d7079ccb47',1,'TiXmlBase']]]
];
