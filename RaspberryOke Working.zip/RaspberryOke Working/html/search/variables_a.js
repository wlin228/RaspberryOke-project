var searchData=
[
  ['origin_5flyrics_757',['origin_lyrics',['../class_lyrics.html#a7622a4de4a6e2e8f0dbd462924346911',1,'Lyrics']]]
];
