var searchData=
[
  ['name_751',['name',['../class_ti_xml_attribute.html#afcbe165f33f08cf9b24daa33f0ee951a',1,'TiXmlAttribute']]],
  ['newlrc_752',['newlrc',['../class_song.html#a4fea0215c7b5e3d5d705b92c5f526e9a',1,'Song']]],
  ['next_753',['next',['../class_ti_xml_node.html#a2f329cc993d2d34df76e17dcbb776b45',1,'TiXmlNode::next()'],['../class_ti_xml_attribute.html#ae851adf61b80cf45b797fee77dea135f',1,'TiXmlAttribute::next()']]],
  ['node_754',['node',['../class_ti_xml_handle.html#ac5429de14bb78b16288bac5bf33c6858',1,'TiXmlHandle']]],
  ['npos_755',['npos',['../class_ti_xml_string.html#a8f4422d227088dc7bec96f479b275d0a',1,'TiXmlString']]],
  ['nullrep_5f_756',['nullrep_',['../class_ti_xml_string.html#ae1f9e0de28328eed27d5623ff67a3191',1,'TiXmlString']]]
];
