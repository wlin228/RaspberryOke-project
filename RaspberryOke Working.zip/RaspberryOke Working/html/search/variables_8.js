var searchData=
[
  ['max_5frows_747',['max_rows',['../class_media.html#aa9a92038accc45068f925a35060c94a9',1,'Media']]],
  ['media_748',['media',['../class_media.html#ad90dcb771a154b859c4fb4fe584a17b4',1,'Media']]],
  ['min_749',['min',['../class_my_time.html#a58fa726da437a308336fcad85cc16a31',1,'MyTime']]],
  ['model_750',['model',['../class_testing.html#a15c4addb2745284cddc92bf6cd6ace39',1,'Testing']]]
];
