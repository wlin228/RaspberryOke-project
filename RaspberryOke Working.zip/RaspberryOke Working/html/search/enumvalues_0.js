var searchData=
[
  ['max_5fentity_5flength_814',['MAX_ENTITY_LENGTH',['../class_ti_xml_base.html#ab251e9d7b9102b9aedb2fdaed2ecfe55aeb571e41586d47e28f60445cb9b41d49',1,'TiXmlBase']]]
];
