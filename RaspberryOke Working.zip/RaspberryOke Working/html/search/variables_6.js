var searchData=
[
  ['indent_734',['indent',['../class_ti_xml_printer.html#a672fda389bb3f5a2ae8ead867f9a2536',1,'TiXmlPrinter']]]
];
