var searchData=
[
  ['ftpfile_405',['FtpFile',['../struct_testing_1_1_ftp_file.html',1,'Testing']]]
];
