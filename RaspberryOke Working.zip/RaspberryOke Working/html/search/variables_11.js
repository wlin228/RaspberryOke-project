var searchData=
[
  ['value_808',['value',['../class_ti_xml_node.html#aead528b3cedc33c16a6c539872c7cc8b',1,'TiXmlNode::value()'],['../class_ti_xml_attribute.html#ae9e4e5f442347434b1da43954cc1b411',1,'TiXmlAttribute::value()']]],
  ['version_809',['version',['../class_ti_xml_declaration.html#ab9eb14dc9cb78e3a8a0636d5d6a5d04d',1,'TiXmlDeclaration']]]
];
